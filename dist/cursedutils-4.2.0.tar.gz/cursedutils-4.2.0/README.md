# cursedutils
do unholy things to python

Mostly esoteric python.

# BEWARE OF THE DEATH MODULE. IF YOU RUN ANY OF ITS CODE, THERE WILL BE MUCH WEEPING AND GNASHING OF TEETH.
